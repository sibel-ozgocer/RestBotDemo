﻿namespace Domain.Common;
/// <summary>
/// abstraction nedir
/// </summary>
public abstract class BaseEntity
{
    public int Id { get; set; }
}
