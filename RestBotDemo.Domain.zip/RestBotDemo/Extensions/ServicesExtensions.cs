﻿using Microsoft.EntityFrameworkCore;
using Persistence.Context;

namespace RestBotDemo.Api.Extensions
{
    //extensıons metotları statık class lar ıcıne yazılır.
    public static class ServicesExtensions
    {
        public static void ConfigureSqlServer(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<AppDbContext>(options =>
      options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));
        }
    }
}
