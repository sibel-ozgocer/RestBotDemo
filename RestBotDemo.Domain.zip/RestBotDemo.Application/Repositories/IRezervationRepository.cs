﻿using RestBot.Domain.Entities;

namespace RestBotDemo.Application.Repositories

{
    public interface IRezervationRepository : IBaseRepository<Reservation>
    {
    }
}
