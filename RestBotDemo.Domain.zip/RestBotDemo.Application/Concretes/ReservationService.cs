﻿using RestBotDemo.Application.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestBotDemo.Application.Concretes
{
    public class ReservationService<T>:BaseService<T>, IRezervationService<T> where T: class
    {
    }
}
